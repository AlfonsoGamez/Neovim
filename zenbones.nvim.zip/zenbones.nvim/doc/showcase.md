# Showcase

See also the
[vimcolorschemes page](https://vimcolorschemes.com/mcchrish/zenbones.nvim).

## Neobones

<img width="1128" alt="Screen Shot 2021-10-31 at 8 49 26 AM" src="https://user-images.githubusercontent.com/7200153/139562404-70bc126e-e078-4190-a25e-41a17fa1fbaf.png">
<img width="1128" alt="Screen Shot 2021-10-31 at 8 49 34 AM" src="https://user-images.githubusercontent.com/7200153/139562407-0bb842ee-4841-4c29-af77-4c9e869fca35.png">

## Vimbones

<img width="1128" alt="Screen Shot 2021-10-31 at 8 49 48 AM" src="https://user-images.githubusercontent.com/7200153/139562409-c11dfb78-b705-40a3-931d-2a47587f0838.png">

## Zenwritten

<img width="1128" alt="Screen Shot 2021-10-31 at 8 55 46 AM" src="https://user-images.githubusercontent.com/7200153/139562479-830493e8-486e-4861-82d3-d3b73c2f37cb.png">
<img width="1128" alt="Screen Shot 2021-10-31 at 8 50 17 AM" src="https://user-images.githubusercontent.com/7200153/139562413-e1765ad4-ef96-4476-a172-242a2df42918.png">

## Rosebones

<img width="1128" alt="Screen Shot 2021-10-31 at 8 50 43 AM" src="https://user-images.githubusercontent.com/7200153/139562414-c6188910-a359-4188-83d1-2a63efad820d.png">
<img width="1128" alt="Screen Shot 2021-10-31 at 8 50 48 AM" src="https://user-images.githubusercontent.com/7200153/139562416-371343d6-92bc-48fd-9dff-f062341c0ce7.png">

## Forestbones

<img width="1128" alt="Screen Shot 2021-10-31 at 8 51 27 AM" src="https://user-images.githubusercontent.com/7200153/139562418-81658124-b142-4012-b4f7-8248a83658cf.png">
<img width="1128" alt="Screen Shot 2021-10-31 at 8 51 40 AM" src="https://user-images.githubusercontent.com/7200153/139562419-124c9fd6-0940-457c-bd13-0edf78fe3427.png">

## Nordbones

<img width="1128" alt="Screen Shot 2021-10-31 at 8 51 59 AM" src="https://user-images.githubusercontent.com/7200153/139562420-7af0cbe9-c974-44b3-801c-ed8702a6072f.png">

## Tokyobones

<img width="1128" alt="Screen Shot 2021-10-31 at 8 52 12 AM" src="https://user-images.githubusercontent.com/7200153/139562421-aa2b0fc2-ee0e-4e43-91b4-b9a8da26e1d0.png">
<img width="1128" alt="Screen Shot 2021-10-31 at 8 52 20 AM" src="https://user-images.githubusercontent.com/7200153/139562422-ef25c51d-6c1d-48d1-85f6-0c6a908dda6b.png">

## Duckbones

<img width="1128" alt="Screen Shot 2021-11-04 at 9 45 11 AM" src="https://user-images.githubusercontent.com/7200153/140243463-03632d42-c53d-41ee-96ac-8a657694f81c.png">

## Zenburned

<img width="1128" alt="Screen Shot 2021-11-04 at 9 45 11 AM" src="https://user-images.githubusercontent.com/7200153/140294924-1924e508-a32c-4529-b135-a61d957fa251.png">
