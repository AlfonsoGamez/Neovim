return require(vim.g.randombones_colors_name .. ".palette")
