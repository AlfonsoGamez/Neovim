local util = require "zenbones.util"

local M = {}

M.light = util.palette_extend({}, "light")
M.dark = util.palette_extend({}, "dark")

return M
